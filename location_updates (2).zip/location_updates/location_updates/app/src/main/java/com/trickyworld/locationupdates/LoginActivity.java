package com.trickyworld.locationupdates;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.trickyworld.locationupdates.Retrofit.RetroInstance;
import com.trickyworld.locationupdates.models.LoginModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    Button loginbtn;
    EditText username,password;
    String name,pass;
    CheckBox checkBox;
    SharedPrferenceManager sharedPrferenceManager;
    TextView sign_up;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username=findViewById(R.id.ed_email);
        password=findViewById(R.id.ed_password);
        loginbtn=findViewById(R.id.btn_login);
        checkBox=findViewById(R.id.checkboz);
//        sign_up=findViewById(R.id.tv_sign_up);
//        sign_up.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(LoginActivity.this,RegisterationActivity.class));
//            }
//        });

        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkBox.isChecked()) {
                    SharedPreferences sharedPreferences = getSharedPreferences("flag", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("login", true);
                    editor.apply();
                }else {
                    SharedPreferences sharedPreferences = getSharedPreferences("flag", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("login", false);
                    editor.apply();

                }
            }
        });
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                login();
                loginApi();
            }
        });
    }
    private void loginApi() {
        name = username.getText().toString();
        pass = password.getText().toString();
//      Api Call
        Call<LoginModel> call= RetroInstance
                .getInstance()
                .getApiInterface()
                .login(name,pass);
        call.enqueue(new Callback<LoginModel>() {
            @Override
            public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {
                LoginModel loginModel=response.body();
                if (response.isSuccessful()){
                    if (loginModel.getStatus().equals("1")){
                        String uname = loginModel.getUser_Details().getUM_User_First_Name();
                        Toast.makeText(LoginActivity.this, loginModel.getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(LoginActivity.this,MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        intent.putExtra("name",uname);
                        startActivity(intent);
                        finish();
                    }

                }
                Toast.makeText(LoginActivity.this, loginModel.getMessage(), Toast.LENGTH_SHORT).show();
            }


            @Override
            public void onFailure(Call<LoginModel> call, Throwable t) {
                Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    // fields validation
    private void login() {
        if (username.getText().toString().equalsIgnoreCase("")){
            username.requestFocus();
            username.setError("Please enter Username.");
        }
        if (password.getText().toString().equalsIgnoreCase("")){
            password.requestFocus();
            password.setError("Please enter your Password.");
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}