package com.trickyworld.locationupdates.Retrofit;

import com.trickyworld.locationupdates.models.LoginModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {
    @FormUrlEncoded
    @POST("Account/UserLogin")
    Call<LoginModel> login(
            @Field("UM_User_Id") String um_user_id,
            @Field("UM_User_Password") String um_user_password
    );
}
