package com.trickyworld.locationupdates;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.HashMap;

public class  SharedPrferenceManager {
    private final SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Context context;
    int Private_mode = 0;
    private static final String SHARED_PREF_NAME="save";
    private static final String IS_LOGED_IN="login";
    public static final String KEY_EMAIL="email";
    public static final String KEY_PASSWORD="password";

    public SharedPrferenceManager(Context context){
        this.context=context;
        sharedPreferences=context.getSharedPreferences(SHARED_PREF_NAME,Private_mode);
        editor=sharedPreferences.edit();

    }

    public void creatLoginSeassion(String email,String password){
        editor.putBoolean(IS_LOGED_IN,true);
        editor.putString(KEY_EMAIL,email);
        editor.putString(KEY_PASSWORD,password);
        editor.commit();

    }
    public boolean isLoggedIn(){
        return sharedPreferences.getBoolean(IS_LOGED_IN,false);
    }
    public void checkLogin(){

        if (!this.isLoggedIn()){
            Intent intent=new Intent(context,LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

    }
    public HashMap< String,String> getUserDetails() {
        HashMap<String,String>user=new HashMap<String, String>();
        user.put(KEY_EMAIL,sharedPreferences.getString(KEY_EMAIL,null));
        user.put(KEY_PASSWORD,sharedPreferences.getString(KEY_PASSWORD,null));
        return user;
    }
    public void logoutUser(){
        editor.clear();
        editor.commit();
        Intent intent=new Intent(context,LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
