package com.trickyworld.locationupdates.Retrofit;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetroInstance {



    private static RetroInstance retroInstance;
    public static String BASE_URL="https://etsapi.fuelly.pk/api/";
    private static Retrofit retrofit;
    private RetroInstance() {
        retrofit=new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }
    public static synchronized RetroInstance getInstance(){
        if (retroInstance ==null){
            retroInstance =new RetroInstance();
        }
        return retroInstance;
    }
    public ApiInterface getApiInterface(){
        return retrofit.create(ApiInterface.class);
    }
}
