package com.trickyworld.locationupdates;

public class UserDetail {

    private String $id;
    private int Coperation;
    private String Client_Code;
    private String Company_Code;
    private String Company_Name;
    private String UM_User_Id;
    private String UM_User_Password;
    private String UM_User_First_Name;
    private String UM_User_Last_Name;
    private String UM_User_DOB;
    private String UM_User_Gender;
    private String UM_User_Email;
    private String UM_User_Contact_Number;
    private String UM_User_Cell_Number;
    private String UM_User_Address;
    private int UM_User_IsAdmin;
    private int UM_User_IsActive;
    private int UM_Role_Code;
    private int Designation_Code;
    private String UM_Manager_Id;
    private String UM_HOD_Id;
    private String Employee_Code;
    private String Extra_Authentication;
    private String Authentication_Code;
    private String Tracking_Flag;
    private String Mobile_App_Flag;
    private String User_Device_Id;
    private String Created_By;
    private String Created_Date_Time;
    private String Edited_By;
    private String Edited_Date_Time;
    private String Message_Code;
    private String Message_Title;
    private String LstRoles;

    public UserDetail(String $id, int coperation, String client_Code, String company_Code, String company_Name, String UM_User_Id, String UM_User_Password, String UM_User_First_Name, String UM_User_Last_Name, String UM_User_DOB, String UM_User_Gender, String UM_User_Email, String UM_User_Contact_Number, String UM_User_Cell_Number, String UM_User_Address, int UM_User_IsAdmin, int UM_User_IsActive, int UM_Role_Code, int designation_Code, String UM_Manager_Id, String UM_HOD_Id, String employee_Code, String extra_Authentication, String authentication_Code, String tracking_Flag, String mobile_App_Flag, String user_Device_Id, String created_By, String created_Date_Time, String edited_By, String edited_Date_Time, String message_Code, String message_Title, String lstRoles) {
        this.$id = $id;
        Coperation = coperation;
        Client_Code = client_Code;
        Company_Code = company_Code;
        Company_Name = company_Name;
        this.UM_User_Id = UM_User_Id;
        this.UM_User_Password = UM_User_Password;
        this.UM_User_First_Name = UM_User_First_Name;
        this.UM_User_Last_Name = UM_User_Last_Name;
        this.UM_User_DOB = UM_User_DOB;
        this.UM_User_Gender = UM_User_Gender;
        this.UM_User_Email = UM_User_Email;
        this.UM_User_Contact_Number = UM_User_Contact_Number;
        this.UM_User_Cell_Number = UM_User_Cell_Number;
        this.UM_User_Address = UM_User_Address;
        this.UM_User_IsAdmin = UM_User_IsAdmin;
        this.UM_User_IsActive = UM_User_IsActive;
        this.UM_Role_Code = UM_Role_Code;
        Designation_Code = designation_Code;
        this.UM_Manager_Id = UM_Manager_Id;
        this.UM_HOD_Id = UM_HOD_Id;
        Employee_Code = employee_Code;
        Extra_Authentication = extra_Authentication;
        Authentication_Code = authentication_Code;
        Tracking_Flag = tracking_Flag;
        Mobile_App_Flag = mobile_App_Flag;
        User_Device_Id = user_Device_Id;
        Created_By = created_By;
        Created_Date_Time = created_Date_Time;
        Edited_By = edited_By;
        Edited_Date_Time = edited_Date_Time;
        Message_Code = message_Code;
        Message_Title = message_Title;
        LstRoles = lstRoles;
    }

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public int getCoperation() {
        return Coperation;
    }

    public void setCoperation(int coperation) {
        Coperation = coperation;
    }

    public String getClient_Code() {
        return Client_Code;
    }

    public void setClient_Code(String client_Code) {
        Client_Code = client_Code;
    }

    public String getCompany_Code() {
        return Company_Code;
    }

    public void setCompany_Code(String company_Code) {
        Company_Code = company_Code;
    }

    public String getCompany_Name() {
        return Company_Name;
    }

    public void setCompany_Name(String company_Name) {
        Company_Name = company_Name;
    }

    public String getUM_User_Id() {
        return UM_User_Id;
    }

    public void setUM_User_Id(String UM_User_Id) {
        this.UM_User_Id = UM_User_Id;
    }

    public String getUM_User_Password() {
        return UM_User_Password;
    }

    public void setUM_User_Password(String UM_User_Password) {
        this.UM_User_Password = UM_User_Password;
    }

    public String getUM_User_First_Name() {
        return UM_User_First_Name;
    }

    public void setUM_User_First_Name(String UM_User_First_Name) {
        this.UM_User_First_Name = UM_User_First_Name;
    }

    public String getUM_User_Last_Name() {
        return UM_User_Last_Name;
    }

    public void setUM_User_Last_Name(String UM_User_Last_Name) {
        this.UM_User_Last_Name = UM_User_Last_Name;
    }

    public String getUM_User_DOB() {
        return UM_User_DOB;
    }

    public void setUM_User_DOB(String UM_User_DOB) {
        this.UM_User_DOB = UM_User_DOB;
    }

    public String getUM_User_Gender() {
        return UM_User_Gender;
    }

    public void setUM_User_Gender(String UM_User_Gender) {
        this.UM_User_Gender = UM_User_Gender;
    }

    public String getUM_User_Email() {
        return UM_User_Email;
    }

    public void setUM_User_Email(String UM_User_Email) {
        this.UM_User_Email = UM_User_Email;
    }

    public String getUM_User_Contact_Number() {
        return UM_User_Contact_Number;
    }

    public void setUM_User_Contact_Number(String UM_User_Contact_Number) {
        this.UM_User_Contact_Number = UM_User_Contact_Number;
    }

    public String getUM_User_Cell_Number() {
        return UM_User_Cell_Number;
    }

    public void setUM_User_Cell_Number(String UM_User_Cell_Number) {
        this.UM_User_Cell_Number = UM_User_Cell_Number;
    }

    public String getUM_User_Address() {
        return UM_User_Address;
    }

    public void setUM_User_Address(String UM_User_Address) {
        this.UM_User_Address = UM_User_Address;
    }

    public int getUM_User_IsAdmin() {
        return UM_User_IsAdmin;
    }

    public void setUM_User_IsAdmin(int UM_User_IsAdmin) {
        this.UM_User_IsAdmin = UM_User_IsAdmin;
    }

    public int getUM_User_IsActive() {
        return UM_User_IsActive;
    }

    public void setUM_User_IsActive(int UM_User_IsActive) {
        this.UM_User_IsActive = UM_User_IsActive;
    }

    public int getUM_Role_Code() {
        return UM_Role_Code;
    }

    public void setUM_Role_Code(int UM_Role_Code) {
        this.UM_Role_Code = UM_Role_Code;
    }

    public int getDesignation_Code() {
        return Designation_Code;
    }

    public void setDesignation_Code(int designation_Code) {
        Designation_Code = designation_Code;
    }

    public String getUM_Manager_Id() {
        return UM_Manager_Id;
    }

    public void setUM_Manager_Id(String UM_Manager_Id) {
        this.UM_Manager_Id = UM_Manager_Id;
    }

    public String getUM_HOD_Id() {
        return UM_HOD_Id;
    }

    public void setUM_HOD_Id(String UM_HOD_Id) {
        this.UM_HOD_Id = UM_HOD_Id;
    }

    public String getEmployee_Code() {
        return Employee_Code;
    }

    public void setEmployee_Code(String employee_Code) {
        Employee_Code = employee_Code;
    }

    public String getExtra_Authentication() {
        return Extra_Authentication;
    }

    public void setExtra_Authentication(String extra_Authentication) {
        Extra_Authentication = extra_Authentication;
    }

    public String getAuthentication_Code() {
        return Authentication_Code;
    }

    public void setAuthentication_Code(String authentication_Code) {
        Authentication_Code = authentication_Code;
    }

    public String getTracking_Flag() {
        return Tracking_Flag;
    }

    public void setTracking_Flag(String tracking_Flag) {
        Tracking_Flag = tracking_Flag;
    }

    public String getMobile_App_Flag() {
        return Mobile_App_Flag;
    }

    public void setMobile_App_Flag(String mobile_App_Flag) {
        Mobile_App_Flag = mobile_App_Flag;
    }

    public String getUser_Device_Id() {
        return User_Device_Id;
    }

    public void setUser_Device_Id(String user_Device_Id) {
        User_Device_Id = user_Device_Id;
    }

    public String getCreated_By() {
        return Created_By;
    }

    public void setCreated_By(String created_By) {
        Created_By = created_By;
    }

    public String getCreated_Date_Time() {
        return Created_Date_Time;
    }

    public void setCreated_Date_Time(String created_Date_Time) {
        Created_Date_Time = created_Date_Time;
    }

    public String getEdited_By() {
        return Edited_By;
    }

    public void setEdited_By(String edited_By) {
        Edited_By = edited_By;
    }

    public String getEdited_Date_Time() {
        return Edited_Date_Time;
    }

    public void setEdited_Date_Time(String edited_Date_Time) {
        Edited_Date_Time = edited_Date_Time;
    }

    public String getMessage_Code() {
        return Message_Code;
    }

    public void setMessage_Code(String message_Code) {
        Message_Code = message_Code;
    }

    public String getMessage_Title() {
        return Message_Title;
    }

    public void setMessage_Title(String message_Title) {
        Message_Title = message_Title;
    }

    public String getLstRoles() {
        return LstRoles;
    }

    public void setLstRoles(String lstRoles) {
        LstRoles = lstRoles;
    }
}
