package com.trickyworld.locationupdates.models;

import com.trickyworld.locationupdates.UserDetail;

public class LoginModel {
    private String $id;
    private String Status;
    private String Message;
    UserDetail User_Details;

    public LoginModel(String $id, String status, String message, UserDetail user_Details) {
        this.$id = $id;
        Status = status;
        Message = message;
        User_Details = user_Details;
    }

    public String get$id() {
        return $id;
    }

    public void set$id(String $id) {
        this.$id = $id;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public UserDetail getUser_Details() {
        return User_Details;
    }

    public void setUser_Details(UserDetail user_Details) {
        User_Details = user_Details;
    }
}